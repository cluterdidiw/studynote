def avg(numbers: list) -> float:
    """计算平均值"""
    return sum(numbers) / len(numbers) if numbers else 0.0
